INSERT INTO W_MACHINE_TYPE_D (MACHINE_TYPE_ID,MANUFACTURER,MACHINE_MODEL,RATE_PER_HOUR,NUMBER_OF_MACHINES) VALUES
 (1,'Manufacturer A','Model 1',40,5),
 (2,'Manufacturer A','Model 2',20,3),
 (3,'Manufacturer B','Model 101',100,12),
 (4,'Manufacturer C','Model 201',50,4),
 (5,'Manufacturer C','Model 202',30,2),
 (6,'Manufacturer C','Model 203',8,1),
 (7,'Manufacturer D','Model 301',60,4);
