INSERT INTO W_SALES_CLASS_D (SALES_CLASS_ID,SALES_CLASS_DESC,BASE_PRICE) VALUES
 (1,'Debit Smart',1.6),
 (2,'Credit Smart',1.6),
 (3,'Debit NoSmart',0.8),
 (4,'Credit NoSmart',0.8),
 (5,'Prepaid NoSmart',0.8),
 (6,'Loyalty NoSmart',0.8);
