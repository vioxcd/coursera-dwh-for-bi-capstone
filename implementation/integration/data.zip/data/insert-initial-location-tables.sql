INSERT INTO W_LOCATION_D (LOCATION_ID,LOCATION_NAME) VALUES
 (1,'New York'),
 (2,'Atlanta'),
 (3,'Chicago'),
 (4,'Dallas'),
 (5,'Denver'),
 (6,'Los Angeles'),
 (7,'Seattle'),
 (8,'Toronto'),
 (9,'Montreal'),
 (10,'Vancouver'),
 (11,'London'),
 (12,'Birmingham');
